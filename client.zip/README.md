cd ***memories-app***

***npm start***