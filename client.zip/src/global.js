export const server = 'http://localhost:5000';
// export const server = 'https://memoryjournalapp.herokuapp.com';
