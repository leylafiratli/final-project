module.exports = {
  dbURI:
    'mongodb+srv://user:shani4018@cluster0-ifzlo.mongodb.net/test?retryWrites=true&w=majority',
  jwtKey: 'anVDd8sfj08apvn8f021fspaetrw6iekt'
};
